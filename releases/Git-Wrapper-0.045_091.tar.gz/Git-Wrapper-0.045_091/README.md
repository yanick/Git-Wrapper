# Git::Wrapper

Wrap git(7) command-line interface

## VERSION [![CPAN version](https://badge.fury.io/pl/Git-Wrapper.svg)](http://badge.fury.io/pl/Git-Wrapper)

## BUILD INFO

[![Build Status](https://travis-ci.org/genehack/Git-Wrapper.svg?branch=master)](https://travis-ci.org/genehack/Git-Wrapper)
[![Coverage Status](https://coveralls.io/repos/genehack/Git-Wrapper/badge.svg?branch=master)](https://coveralls.io/r/genehack/Git-Wrapper?branch=master)

## USAGE

See [documentation on CPAN](https://metacpan.org/pod/Git::Wrapper)
